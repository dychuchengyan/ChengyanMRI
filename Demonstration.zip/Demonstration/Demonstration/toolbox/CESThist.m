function CESThist(MTR, xbin, Mask, N_Gau, dataname)
% step 5: histogram 
% xbin=0: 0.005: 0.25;
if nargin<5, dataname=''; end

index=find(Mask);
H1=MTR(index);
H1=H1(~isnan(H1));
% [HS x]=hist(sort(H1(find(H1))), xbin);
% hist(sort(H1(find(H1))),xbin )
[HS x]=hist(sort(H1), xbin);
figure; hist(sort(H1),xbin )
[u, sig, per]=Hist_fitpdf(H1, N_Gau) 
set(gca,'ytick',[]);
set(gca,'ycolor',[1 1 1])
% title( strcat(num2str(N_Gau), ' Gaussian fitting @', dataname)) 
export_fig ( strcat('GuassFIT_', dataname))
xlswrite( strcat('His_', dataname),[x' HS'./sum(HS).*100] );
xlswrite( strcat('GaussFit_', dataname),[u ;sig ;per]);
% 
% xlswrite( strcat('His_', dataname),[x'; HS'./sum(HS)] )
% xlswrite( strcat('GaussFit_', dataname),[u ;sig ;per])



% function [ u, sig, per]=Hist_fitpdf(MTRmap, num)
% 
% %%% given a MTR map fitting with num pdf, i.e. num=2;
% % figure; Imagesc(MTRmap); axis off
% % seg_2D=sort(MTRmap.*roitoolmask(1)); [m,n]=size(seg_2D);
% index=find(MTRmap);
% seg_1D=sort(MTRmap(index));
% 
% 
% %   seg_1D=reshape(seg_2D, m*n,1);
% %   figure; subplot(2,1,1); hist(seg_1D, 32);
% % subplot(2,1,2);
% figure; [u, sig, per]=fit_mix_gaussian(seg_1D, num); refinefig_line