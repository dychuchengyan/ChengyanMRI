function [ u, sig, per]=Hist_fitpdf(MTRmap, num)

%%% given a MTR map fitting with num pdf, i.e. num=2;
% figure; Imagesc(MTRmap); axis off
% seg_2D=sort(MTRmap.*roitoolmask(1)); [m,n]=size(seg_2D);


% index=find(MTRmap);
% seg_1D=sort(MTRmap(index));
seg_1D=sort(MTRmap);

%   seg_1D=reshape(seg_2D, m*n,1);
%   figure; subplot(2,1,1); hist(seg_1D, 32);
% subplot(2,1,2);
figure; [u, sig, per]=fit_mix_gaussian(seg_1D, num); %refinefig_line