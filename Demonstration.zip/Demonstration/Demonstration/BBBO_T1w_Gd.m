clear all
close all

addpath('toolbox')
addpath('export_fig')


Matname=strcat('Gd_contrast_raw')
load (Matname)

% load ('Thmask_brain.mat')
 nnn=9; %slice number 
   
PRE=pre(:,:,nnn);
POST=post(:,:,nnn);

figure
imagesc(POST)
colormap (gray(256))
axis image off

%Thmask=roipoly;

figure
imagesc(PRE)
colormap (gray(256))
axis image off

figure
imagesc(POST)
colormap (gray(256))
axis image off

figure
imagesc((POST-PRE)./PRE.*Thmask, [ 0 3])
colormap (gray(256))
axis image off

D=(POST-PRE)./PRE*100;
% D(D<0)=0;
D(D>500)=0;
CESThist(D, 50, Thmask,2, 'Hist_Gd');


threshold=0.3139;
dMI=medfilt2((POST-PRE)./PRE, [1 1]);
dMI(dMI>threshold)=1;
dMI(dMI<=threshold)=0;

figure
imagesc(dMI.*Thmask, [ 0 2])
colormap (jet)
axis image off
export_fig(strcat('Binary_Gd_slice', num2str(nnn)))

index1=find(dMI.*Thmask==1); size(index1)
index0=find(Thmask==1); size(index0)

Fraction_of_contrast= size(index1)./ size(index0)
% MyCleanup('Gd_slices')

% 

