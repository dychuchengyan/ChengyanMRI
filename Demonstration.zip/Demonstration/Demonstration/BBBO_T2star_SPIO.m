%%% 08/25/2014 making it for the ferritin dynamic processing
clear all
close all

addpath('toolbox')
addpath('export_fig')


Matname=strcat('Dynamic_T2star_SPIO')
load (Matname) 

nslice=5;
ncycle=18;
% Thmask=roipoly;
% save (strcat(Matname),  'MI', 'FOV', 'Thmask')
% save ('FOV', 'FOV')

figure 
imagesc(MI(:,:,nslice,19))
colormap (gray)
axis off


D=100.*(MI(:,:,nslice,ncycle)-MI(:,:,nslice,1))./MI(:,:,nslice,1);
figure 
imagesc(D.*Thmask, [ -100 0])
colormap (gray)
axis off
title ('SPIO contrast')

 D(D<-100)=-100; 
 D(D>0)=0; 
 CESThist(D, 20, Thmask, 2, 'Hist_SPIO');
 
 D=D.*-1;
% D(D>0)=0;
threshold=53.85
dMI=D;
dMI(D>threshold)=1;
dMI(D<=threshold)=0;

figure
imagesc(dMI.*Thmask, [ 0 2])
colormap (jet)
axis off
title (strcat('Binary SPIO slice', num2str(nslice)))


index1=find(dMI.*Thmask==1); size(index1)
index0=find(Thmask==1); size(index0)
Fraction_of_contrast= size(index1)./ size(index0)
